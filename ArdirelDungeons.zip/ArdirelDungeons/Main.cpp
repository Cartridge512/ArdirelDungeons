#include "WindowManager.h"

using namespace std;

int main()
{
	WindowManager::init();

	return 0;
}