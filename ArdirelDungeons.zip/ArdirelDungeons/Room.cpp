#include "Room.h"


Room::Room(void)
{
}

Room::Room(int xx, int yy, int w, int h)
{
	x = xx;
	y = yy;
	width = w;
	height = h;
}

Room::~Room(void)
{
}
